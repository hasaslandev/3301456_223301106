import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HeathNeeds extends StatelessWidget {
  const HeathNeeds({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<CustomIcon> customIcons = [
      CustomIcon(icon: "assets/images/appointment.png", name: "Appointment"),
      CustomIcon(icon: "assets/images/hospital.png", name: "Hospital"),
      CustomIcon(icon: "assets/images/virus.png", name: "Covid-19"),
      CustomIcon(icon: "assets/images/more.png", name: "More"),
      CustomIcon(icon: "assets/images/hospital.png", name: "Hospital"),
      CustomIcon(icon: "assets/images/appointment.png", name: "Appointment"),
    ];

    return Container(
      height: 100,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        separatorBuilder: (BuildContext context, int index) {
          return const SizedBox(width: 12);
        },
        itemCount: customIcons.length,
        itemBuilder: (BuildContext context, int index) {
          return Column(

            children: [
              Container(
                width: 50,
                height: 70,
                padding: const EdgeInsets.all(15),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.blue,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.red,
                      blurRadius: 4,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Image.asset(customIcons[index].icon),
              ),
              const SizedBox(height: 7),
              Text(customIcons[index].name),
            ],
          );
        },
      ),
    );
  }
}

class CustomIcon {
  final String icon;
  final String name;

  CustomIcon({required this.icon, required this.name});
}
