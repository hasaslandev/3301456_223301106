import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';

class UpcomingCard extends StatelessWidget {
  const UpcomingCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,//Ekran genişliğine göre ayarla
          height: 150,
          padding: const EdgeInsets.symmetric(vertical: 22.0, horizontal: 20.0),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withOpacity(0.8),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset(
                      'assets/images/doctor_2.jpg',
                      width: 70,

                    ),
                  ),
                ],
              ),
              const SizedBox(width: 14),
              Column(
                children: [
                 const Padding(
                    padding: EdgeInsets.only(bottom: 5),
                    child: Text(
                      'Prof. Hasan Aslan',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black54,
                      ),
                    ),
                  ),
                  const Text(
                    "Diş Doktoru",
                    style: TextStyle(
                      color: Colors.white70,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 6/*üst*/,horizontal: 8,/*alt*/),
                    decoration: BoxDecoration(
                      color: Colors.grey,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: const [
                        Icon(
                          Ionicons.calendar_outline,
                          size: 18,
                          color: Colors.white,
                        ),
                        Padding(
                          padding: EdgeInsets.only(right: 14,left: 6),
                          child: Text(
                              "Bugün",
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(right: 8.0),
                          child: Icon(
                            Ionicons.time_outline,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                        Text(
                          "15:20 - 20.00",
                          style: TextStyle(color: Colors.white),
                        )
                      ],
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ],
    );
  }
}
