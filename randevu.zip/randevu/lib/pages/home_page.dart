import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:randevu/widgets/heath_needs.dart';
import 'package:randevu/widgets/nearby_doctors.dart';
import 'package:randevu/widgets/upcoming_card.dart';
import 'package:randevu/pages/bildirimler.dart';
class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  //HomePage({Key? key}) : super(key: key);
  String kullaniciAdi='';
  String sifre='';
  @override
  Widget build(BuildContext context) {

    List<dynamic>? data=[];
    data = ModalRoute.of(context)?.settings.arguments as List?;
    kullaniciAdi=data![0];
    sifre=data![1];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor.withOpacity(0.8),
        title: Row(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(kullaniciAdi+sifre),
                Text(
                  "Bugün Nasılsın?",
                  style: Theme.of(context).textTheme.bodySmall, //Burası farklı
                )
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Bildirimler()),
              );
            },
            icon: const Icon(Ionicons.notifications_outline),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Ionicons.log_out_outline),
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(15), //Ekranı uzaklaştırdık
        children: [
          //Upcaming Card
          Text(
            "Öne Çıkan Doktorlar",
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 20),

          Container(
            child: const UpcomingCard(),
          ),
          const SizedBox(height: 20),
          Text(
            "Kategoriler",
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 25),
          //Health Needs
          const HeathNeeds(),
          const SizedBox(height: 20),
          Text(
            "Nearby Doctors",
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 15),
          const NearbyDoctors()

          //Nearby Doctors
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Ionicons.home_outline), label: "Home"),
          BottomNavigationBarItem(
              icon: Icon(Ionicons.calendar), label: "Calendar"),
          BottomNavigationBarItem(icon: Icon(Ionicons.camera), label: "Camera"),
          BottomNavigationBarItem(
              icon: Icon(Ionicons.airplane), label: "Airplane"),
        ],
      ),
    );
  }
}

