import 'package:flutter/material.dart';
import 'package:randevu/pages/home_page.dart';
import 'package:randevu/pages/kaydol.dart';
class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<Login> {
  String kullaniciAdi='';
  String sifre='';
  void kontrol(){
    if((kullaniciAdi.length>=9) && (sifre==9)){
      var data=[];
      data.add(kullaniciAdi);
      data.add(sifre);
      Navigator.push(context, MaterialPageRoute(builder: (context)=> HomePage(),settings:RouteSettings(
        arguments: data,
      ), ));
      Navigator.pushNamed(context,'/home_page');
    }
    else{
      Navigator.pushNamed(context,'/hata');
    }
  }
  void kullaniciAdiText(String text){
    setState(() {
      kullaniciAdi=text;
    });
  }
  void sifreText(String text){
    setState(() {
      sifre=text;
    });
  }
  @override
  Widget build(BuildContext context) {

    bool butonpasif=true;
    if((kullaniciAdi.length>=9) && (sifre==9)){
      butonpasif =false;
    }
    else{
      butonpasif =true;
    }
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            _buildFormField(
              labelText: 'Kullanıcı Adı',
              hintText: 'Kullanıcı adınızı giriniz',
              icon: Icons.person,
            ),
            TextFormField(
              onChanged: (text){kullaniciAdiText(text);},
            ),
            TextFormField(
              onChanged: (text){sifreText(text);},
            ),
             const SizedBox(
              height: 20,
            ),
            _buildFormField(
              labelText: 'Şifre',
              hintText: '*********',
              icon: Icons.lock,
              obscureText: true,
            ),
            const SizedBox(height: 16.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                  onPressed: () {kontrol();
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HomePage()),
                    );
                  },
                  child: const Text('Giriş Yap'),
                ),
                ElevatedButton(
                  onPressed: () { Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) =>Kaydol()),
                  );},
                  child: const Text('Kaydol'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFormField({
    required String labelText,
    required String hintText,
    required IconData icon,
    bool obscureText = false,
  }) {
    return TextFormField(
    //Kişinin kullanıcı adına göre homede isim yazıcak
      //onChanged: (text){kullaniciAdiText(text);},
      obscureText: obscureText,
      decoration: InputDecoration(
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.transparent),
          borderRadius: BorderRadius.circular(5.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.transparent),
          borderRadius: BorderRadius.circular(5.5),
        ),
        prefixIcon: Icon(
          icon,
          color: Colors.teal,
        ),
        hintText: hintText,
        hintStyle: const TextStyle(
          color: Colors.blue,
        ),
        filled: true,
        fillColor: Colors.blue[50],
        labelText: labelText,
        labelStyle: const TextStyle(
          color: Colors.blue,
        ),
      ),
    );
  }

}




